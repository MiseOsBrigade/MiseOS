#!/usr/bin/env bash
set -euo pipefail

mkdir -p publish reports

drafts=(
  "draft-watts-ai-identity-00"
  "draft-watts-ai-identity-conformance-00"
)

status=0

for draft in "${drafts[@]}"; do
  src="ietf/${draft}.xml"

  echo "==> RFCXML validation: ${src}"
  if ! rfclint "${src}" >"reports/${draft}.rfclint.txt" 2>&1; then
    cat "reports/${draft}.rfclint.txt"
    status=1
    continue
  fi

  echo "==> xml2rfc text render: ${draft}"
  if ! xml2rfc --text --out "publish/${draft}.txt" "${src}" \
       >"reports/${draft}.xml2rfc-text.log" 2>&1; then
    cat "reports/${draft}.xml2rfc-text.log"
    status=1
    continue
  fi

  echo "==> xml2rfc HTML render: ${draft}"
  if ! xml2rfc --html --out "publish/${draft}.html" "${src}" \
       >"reports/${draft}.xml2rfc-html.log" 2>&1; then
    cat "reports/${draft}.xml2rfc-html.log"
    status=1
    continue
  fi

  echo "==> idnits submission mode: ${draft}"
  if ! idnits --mode submission --no-color --no-progress \
       "publish/${draft}.txt" \
       >"reports/${draft}.idnits.txt" 2>&1; then
    cat "reports/${draft}.idnits.txt"
    status=1
  fi
done

sha256sum ietf/*.xml publish/* 2>/dev/null > reports/SHA256SUMS.txt || true

if [[ "${status}" -ne 0 ]]; then
  echo "IETF publication gate FAILED. Review reports/."
  exit "${status}"
fi

echo "IETF publication gate PASSED."
