# AID-1 IETF Publication CI Package

This package turns the remaining publication gate into a reproducible build.

## Drafts

- `ietf/draft-watts-ai-identity-00.xml`
- `ietf/draft-watts-ai-identity-conformance-00.xml`

## Gate

The GitHub Actions workflow:

1. installs `xml2rfc==3.34.0`, `rfclint`, and the current `@ietf-tools/idnits`;
2. validates each RFCXML v3 source with `rfclint`;
3. renders authoritative `.txt` and `.html` outputs with `xml2rfc`;
4. runs `idnits --mode submission` against the rendered plaintext;
5. uploads renderings and reports as a GitHub Actions artifact.

A failed validation, render, or idnits check fails the workflow.

## Local use

Install:

```bash
python -m pip install "xml2rfc==3.34.0" rfclint
npm install --global @ietf-tools/idnits
```

Run:

```bash
bash scripts/ietf-publish-check.sh
```

or:

```bash
make all
```

Do not describe either Internet-Draft as submission-ready until this gate passes.

## Datatracker

After a clean gate, submit the RFCXML v3 source through the Datatracker.
The generated plaintext is useful for review and independent `idnits` evidence,
but Datatracker can generate renderings from the submitted RFCXML.
